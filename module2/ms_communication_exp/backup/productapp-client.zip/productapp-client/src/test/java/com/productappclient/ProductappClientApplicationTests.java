package com.productappclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductappClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
