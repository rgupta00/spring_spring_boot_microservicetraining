package com.productapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductappServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductappServiceApplication.class, args);
	}

}
