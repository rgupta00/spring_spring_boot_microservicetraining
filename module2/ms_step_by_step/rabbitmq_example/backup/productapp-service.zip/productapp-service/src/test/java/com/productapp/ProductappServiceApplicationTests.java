package com.productapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductappServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
