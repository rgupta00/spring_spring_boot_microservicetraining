package com.productapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductappConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductappConsumerApplication.class, args);
	}

}
